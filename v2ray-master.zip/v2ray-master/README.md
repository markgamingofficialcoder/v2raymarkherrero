wget -N --no-check-certificate -q -O install.sh "https://raw.githubusercontent.com/itsgelogomayee/v2ray/master/install.sh" && chmod +x install.sh && bash install.sh
